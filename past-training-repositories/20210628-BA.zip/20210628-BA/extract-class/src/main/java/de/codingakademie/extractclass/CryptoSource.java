package de.codingakademie.extractclass;

interface CryptoSource {
    long seed();
}
