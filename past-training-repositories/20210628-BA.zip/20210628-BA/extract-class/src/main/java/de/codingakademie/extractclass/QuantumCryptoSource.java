package de.codingakademie.extractclass;

public class QuantumCryptoSource implements CryptoSource {
    @Override
    public long seed() {
        return 956454217;
    }
}
