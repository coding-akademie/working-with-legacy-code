# Extract Class

Your task:
* What are concepts and are those properly layed out in the code?
* Are the unnecassary details? Can you refactor them into reuseable code?