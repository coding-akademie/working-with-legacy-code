# Golden-Master with Seam

Your task:
* create a golden master from BuildSeamsInto's System.out.println AND network communication