package de.codingakademie.seam;

import org.junit.jupiter.api.Test;

public class BuildSeamsIntoTest {
    @Test
    public void goldenMasterTest() throws Exception {
        // TODO create a golden master from BuildSeamsInto's System.out.println AND network communication
    }
}
