package org.craftedsw.tripservicekata.trip;

public class TripDAOTest {

}
