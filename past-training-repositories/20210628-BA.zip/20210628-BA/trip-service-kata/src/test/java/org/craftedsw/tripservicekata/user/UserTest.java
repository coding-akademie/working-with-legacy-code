package org.craftedsw.tripservicekata.user;

public class UserTest {

}
