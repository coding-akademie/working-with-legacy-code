package de.codingakademie.fizzbuzz;

import org.junit.jupiter.api.Test;

public class FizzBuzzTest {

    @Test
    public void goldenMasterTest() throws Exception {
        // TODO create a golden master from FizzBuzz's System.out.println
    }
}
