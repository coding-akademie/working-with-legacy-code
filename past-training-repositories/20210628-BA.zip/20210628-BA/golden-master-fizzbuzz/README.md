# Golden-Master with FizzBuzz

Your task:
* create a golden master from FizzBuzz's System.out.println